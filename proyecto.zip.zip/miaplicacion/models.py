from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class Usuarios(models.Model):
    nombre = models.CharField(max_length=50)
    email = models.EmailField()

    def __str__(self) -> str:
        return f"{self.nombre}"
   
   
class Recetas(models.Model):
    nombre = models.CharField(max_length=50)
    redsocial = models.CharField(max_length=50)
    autorpublica = models.CharField(max_length=50)
    link = models.CharField(max_length=50)
    imagen = models.ImageField(upload_to= "recetas")
    
    
    def __str__(self) -> str:
        return f"{self.nombre}"

class Manualidades(models.Model):
    nombre = models.CharField(max_length=50)
    redsocial = models.CharField(max_length=50)
    autorpublica = models.CharField(max_length=100)
    link = models.CharField(max_length=200)
    imagen = models.ImageField(upload_to= "manualidades")

    def __str__(self) -> str:
        return f"{self.nombre}"


class Turismo(models.Model):
    nombre = models.CharField(max_length=50)
    redsocial = models.CharField(max_length=50)
    autorpublica = models.CharField(max_length=50)
    link = models.CharField(max_length=50)
    imagen = models.ImageField(upload_to= "turismo")
    
    def __str__(self) -> str:
        return f"{self.nombre}"
    


#______________________________________________________________________________________________________

class Aboutme(models.Model):
    texto = models.TextField()

    def __str__(self) -> str:
        return f"{self.texto}"


class Avatar(models.Model):
    imagen = models.ImageField(upload_to="avatares")
    user = models.ForeignKey(User, on_delete= models.CASCADE)

    def __str__(self):
        return f"{self.user} [{self.imagen}]"