from django.contrib import admin
from .models import Turismo, Recetas, Manualidades


# Register your models here.

admin.site.register(Turismo)
admin.site.register(Recetas)
admin.site.register(Manualidades)
