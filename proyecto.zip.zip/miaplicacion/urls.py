from django.urls import path, include
from .views import *


from django.contrib.auth.views import LogoutView


urlpatterns = [
    path('', index, name="inicio"),
    
    path('usuarios/', usuarios, name="usuarios"),
    path('turismo/', turismo, name="turismo"),
    path('manualidades/', manualidades, name="manualidades"),
    path('aboutme/', aboutme, name="aboutme"),
    path('recetas/', recetas, name="recetas"),
    
    path('update_recetas/<id_receta>/', updateRecetas, name="update_recetas"),
    path('delete_recetas/<id_receta>/', deleteRecetas, name="delete_recetas"),
    path('create_recetas/', createRecetas, name="create_recetas"),
    
  
    path('update_manualidades/<id_manualidad>/', updateManualidades, name="update_manualidades"),
    path('delete_manualidades/<id_manualidad>/', deleteManualidades, name="delete_manualidades"),
    path('create_manualidades/', createManualidades, name="create_manualidades"),

    path('update_turismo/<id_turista>/', updateTurismo, name="update_turismo"),
    path('delete_turismo/<id_turista>/', deleteTurismo, name="delete_turismo"),
    path('create_turismo/', createTurismo, name="create_turismo"),


    path('login/', login_request, name="login"),
    path('logout/', LogoutView.as_view(template_name="miaplicacion/logout.html"), name="logout"),
    path('register/', register, name="register"),
    

    path('buscar_email/', buscarEmail, name="buscar_email"),
     path('buscar2/', buscar2, name="buscar2"),

    path('editar_perfil/', editarPerfil, name="editar_perfil"),

    path('agregar_avatar/', agregarAvatar, name="agregar_avatar"),

]
