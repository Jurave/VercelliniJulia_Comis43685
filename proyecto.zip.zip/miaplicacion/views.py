from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.urls import reverse_lazy
from .models import *
from .forms import *


from django.views.generic import ListView
from django.views.generic import CreateView
from django.views.generic import UpdateView
from django.views.generic import DetailView
from django.views.generic import DeleteView


from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required

# Create your views here.

def usuarios(request):
    ctx = {"usuarios": Usuarios.objects.all() }
    return render(request, "miaplicacion/usuarios.html", ctx)

def index(request):
    return render(request, 'miaplicacion/base.html')

@login_required
def usuarios(request):
    ctx = {"usuarios": Usuarios.objects.all()}
    return render(request, "miaplicacion/usuarios.html", ctx)

@login_required
def aboutme(request):
    return render(request, "miaplicacion/aboutme.html")

def buscarposteos(request):
    return render(request, "miaplicacion/buscarPosteos.html")



@login_required
def recetas(request):
    ctx = {"recetas": Recetas.objects.all()}
    return render(request, "miaplicacion/recetas.html", ctx)


@login_required
def createRecetas(request):    
    if request.method == "POST":
        miForm = RecetasForm(request.POST, request.FILES)
        print(miForm)
        if miForm.is_valid():        
            r_nombre = miForm.cleaned_data.get('nombre')
            r_redsocial = miForm.cleaned_data.get('redsocial')
            r_autorpublica = miForm.cleaned_data.get('autorpublica')
            r_link = miForm.cleaned_data.get('link')
            r_imagen = miForm.cleaned_data.get('imagen')      
            receta = Recetas(nombre=r_nombre,
                             redsocial=r_redsocial,
                             autorpublica=r_autorpublica,
                             link=r_link,
                             imagen=r_imagen                       
                             )
            receta.save()
            return redirect(reverse_lazy('recetas'))
    else:
        miForm = RecetasForm()

    return render(request, "miaplicacion/recetasForm.html", {"form":miForm})

@login_required
def deleteRecetas(request, id_receta):
    receta = Recetas.objects.get(id = id_receta)
    receta.delete()
    return redirect(reverse_lazy('recetas'))

@login_required
def updateRecetas(request, id_receta):
    receta = Recetas.objects.get(id = id_receta)    
    if request.method == "POST":      
        miForm = RecetasForm(request.POST, request.FILES)
        if miForm.is_valid():
            receta.nombre = miForm.cleaned_data.get('nombre')
            receta.redsocial = miForm.cleaned_data.get('redsocial')
            receta.autorpublica = miForm.cleaned_data.get('autorpublica')
            receta.link = miForm.cleaned_data.get('link')
            receta.imagen = miForm.cleaned_data.get('imagen')
            receta.save()
            return redirect(reverse_lazy('recetas'))
    else:
        miForm = RecetasForm(initial={'nombre':receta.nombre,
                                      'redsocial':receta.redsocial,
                                      'autorpublica':receta.autorpublica,
                                      'link':receta.link,
                                      'imagen':receta.imagen
                                      })         
    return render(request, "miaplicacion/recetasForm.html", {'form': miForm})


#_______________Manualidades_______________________________________________________________

@login_required
def manualidades(request):
    ctx = {"manualidades": Manualidades.objects.all()}
    return render(request, "miaplicacion/manualidades.html", ctx)


@login_required
def createManualidades(request):
    if request.method == "POST":
        miForm = ManualidadesForm(request.POST, request.FILES)
        print(miForm)
        if miForm.is_valid():        
            manualidad_nombre = miForm.cleaned_data.get('nombre')
            manualidad_redsocial = miForm.cleaned_data.get('redsocial')
            manualidad_autorpublica = miForm.cleaned_data.get('autorpublica')
            manualidad_link = miForm.cleaned_data.get('link')
            manualidad_imagen = miForm.cleaned_data.get('imagen')
            manualidad = Manualidades(nombre=manualidad_nombre,
                             redsocial=manualidad_redsocial,
                             autorpublica=manualidad_autorpublica,
                             link=manualidad_link,
                             imagen=manualidad_imagen       
                             )
            manualidad.save()
            return redirect(reverse_lazy('manualidades'))
    else:
        miForm = ManualidadesForm()

    return render(request, "miaplicacion/manualidadesForm.html", {"form":miForm})

@login_required
def deleteManualidades(request, id_manualidad):
    manualidad = Manualidades.objects.get(id = id_manualidad)
    manualidad.delete()
    return redirect(reverse_lazy('manualidades'))

@login_required
def updateManualidades(request, id_manualidad):
    manualidad = Manualidades.objects.get(id = id_manualidad)
    if request.method == "POST":
        miForm = ManualidadesForm(request.POST, request.FILES)
        if miForm.is_valid():
            manualidad.nombre = miForm.cleaned_data.get('nombre')
            manualidad.redsocial = miForm.cleaned_data.get('redsocial')
            manualidad.autorpublica = miForm.cleaned_data.get('autorpublica')
            manualidad.link = miForm.cleaned_data.get('link')
            manualidad.imagen = miForm.cleaned_data.get('imagen')
            manualidad.save()
            return redirect(reverse_lazy('manualidades'))
    else:
        miForm = ManualidadesForm(initial={'nombre':manualidad.nombre,
                                      'redsocial':manualidad.redsocial,
                                      'autorpublica':manualidad.autorpublica,
                                      'link':manualidad.link,
                                      'imagen':manualidad.imagen
                                      })         
    return render(request, "miaplicacion/manualidadesForm.html", {'form': miForm})


#______________________Turismo__________________________________________________________________

@login_required
def turismo(request):
    ctx = {"turismo": Turismo.objects.all()}
    return render(request, "miaplicacion/turismo.html", ctx)


@login_required
def createTurismo(request):    
    if request.method == "POST":
        miForm = TurismoForm(request.POST, request.FILES)
        print(miForm)
        if miForm.is_valid():        
            r_nombre = miForm.cleaned_data.get('nombre')
            r_redsocial = miForm.cleaned_data.get('redsocial')
            r_autorpublica = miForm.cleaned_data.get('autorpublica')
            r_link = miForm.cleaned_data.get('link')
            r_imagen = miForm.cleaned_data.get('imagen') 
            turista = Turismo(nombre=r_nombre,
                             redsocial=r_redsocial,
                             autorpublica=r_autorpublica,
                             link=r_link,
                             imagen=r_imagen                       
                             )
            turista.save()
            return redirect(reverse_lazy('turismo'))
    else:
        miForm = TurismoForm()

    return render(request, "miaplicacion/turismoForm.html", {"form":miForm})

@login_required
def deleteTurismo(request, id_turista):
    turista = Turismo.objects.get(id = id_turista)
    turista.delete()
    return redirect(reverse_lazy('turismo'))

@login_required
def updateTurismo(request, id_turista):
    turista = Turismo.objects.get(id = id_turista)    
    if request.method == "POST":
        miForm = TurismoForm(request.POST, request.FILES)
        if miForm.is_valid():
            turista.nombre = miForm.cleaned_data.get('nombre')
            turista.redsocial = miForm.cleaned_data.get('redsocial')
            turista.autorpublica = miForm.cleaned_data.get('autorpublica')
            turista.link = miForm.cleaned_data.get('link')
            turista.imagen = miForm.cleaned_data.get('imagen')
            turista.save()
            return redirect(reverse_lazy('turismo'))
    else:
        miForm = TurismoForm(initial={'nombre':turista.nombre,
                                      'redsocial':turista.redsocial,
                                      'autorpublica':turista.autorpublica,
                                      'link':turista.link,
                                      'imagen':turista.imagen
                                      })         
    return render(request, "miaplicacion/turismoForm.html", {'form': miForm})

#---------------------------------------------------------------------------------------

# Create your views here.

def login_request(request):
    if request.method == "POST":
        miForm = AuthenticationForm(request, data=request.POST)        
        if miForm.is_valid():        
            usuario = miForm.cleaned_data.get('username')
            clave = miForm.cleaned_data.get('password')
            user = authenticate(username=usuario, password=clave)
            if user is not None:
               login(request, user)
               try:
                    avatar = Avatar.objects.get(user=request.user.id).imagen.url
               except:
                    avatar = '/media/avatares/default.png'
               finally:
                    request.session['avatar'] = avatar

               return render(request, "miaplicacion/base.html", {"mensaje": f"Bienvenido {usuario}"})
            else:
                return render(request, "miaplicacion/login.html", {"form":miForm, "mensaje": "Datos Inválidos"})
        else:    
            return render(request, "miaplicacion/login.html", {"form":miForm, "mensaje": "Datos Inválidos"})

    miForm = AuthenticationForm()

    return render(request, "miaplicacion/login.html", {"form":miForm})

 
def register(request):
    if request.method == 'POST':
        form = RegistroUsuariosForm(request.POST)  
        if form.is_valid():  
            usuario = form.cleaned_data.get('username')
            form.save()
            return render(request, "miaplicacion/base.html", {"mensaje":"Usuario Creado"})        
    else:
        form = RegistroUsuariosForm() 

    return render(request, "miaplicacion/registro.html", {"form": form})


#___Editar Perfil
#
@login_required
def editarPerfil(request):
    usuario = request.user
    if request.method == "POST":
        form = UserEditForm(request.POST)
        if form.is_valid():
            usuario.email = form.cleaned_data.get('email')
            usuario.password1 = form.cleaned_data.get('password1')
            usuario.password2 = form.cleaned_data.get('password2')
            usuario.first_name = form.cleaned_data.get('first_name')
            usuario.last_name = form.cleaned_data.get('last_name')
            usuario.save()
            return render(request, "miaplicacion/base.html", {'mensaje': f"Usuario {usuario.username} actualizado correctamente"})
        else:
            return render(request, "miaplicacion/editarPerfil.html", {'form': form})
    else:
        form = UserEditForm(instance=usuario)
    return render(request, "miaplicacion/editarPerfil.html", {'form': form, 'usuario':usuario.username})


#___________________Avatar____________________________________________________________________________

@login_required
def agregarAvatar(request):
    if request.method == "POST":
        form = AvatarFormulario(request.POST, request.FILES)
        if form.is_valid():
            u = User.objects.get(username=request.user)

            avatarViejo = Avatar.objects.filter(user=u)
            
            if len(avatarViejo) > 0:
                avatarViejo[0].delete()

            avatar = Avatar(user=u, imagen=form.cleaned_data['imagen'])
            avatar.save()
            
            imagen = Avatar.objects.get(user=request.user.id).imagen.url
            request.session['avatar'] = imagen

            return render(request, "miaplicacion/base.html")
    else:
        form = AvatarFormulario()
    return render(request, "miaplicacion/agregarAvatar.html", {'form': form})


#_________________buscar___________________________________

@login_required
def buscarEmail(request):
    return render(request, "miaplicacion/buscarEmail.html")

@login_required
def buscar2(request):
    if request.GET['email']:
        email = request.GET['email']
        user = Usuarios.objects.filter(email__icontains=email)
        return render(request, "miaplicacion/resultadosEmail.html", {"email": email, "user": user})
    
    return HttpResponse("No se ingresaron datos para buscar!")